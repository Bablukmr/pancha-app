import AuthRouts from './authRouts'

function AuthLayout() {
  return (
    <div>
        <AuthRouts/>
    </div>
  )
}

export default AuthLayout
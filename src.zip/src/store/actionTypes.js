export const USER_DETAIL = "USER_DETAIL";

// export const USER_GLOBALS = "USER_GLOBALS";

export const USER_DATA = "USER_DATA";

export const SETTINGS = "SETTINGS";

export const LANGUAGE = "LANGUAGE";

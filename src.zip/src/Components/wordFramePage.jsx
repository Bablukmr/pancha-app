import { useEffect, useState, useRef } from "react";
import WordDetail from "./wordDetail";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { Pagination } from "swiper/modules";
import { useSelector } from "react-redux";

function WordFramePage({ wordData, showVideoFirst }) {
  const language = useSelector((state) => state.AuthReducer.language);

  const [chinese, setChinese] = useState(false);
  const [french, setFrench] = useState(false);
  const [spanish, setSpanish] = useState(false);

  const videoRef = useRef();

  useEffect(() => {
    const ee = () => {
      // alert("hi");
      setTimeout(() => {
        videoRef.current.play();
      }, 500);
    };

    videoRef.current.addEventListener("canplay", ee);

    return () => {
      videoRef.current.removeEventListener("canplay", ee);
    };
  }, []);

  useEffect(() => {
    if (language) {
      setSpanish(language.filter((d) => d.name === "Spanish")[0]?.active);
      setFrench(language.filter((d) => d.name === "French")[0]?.active);
      setChinese(language.filter((d) => d.name === "Chinese")[0]?.active);
    }
  }, [language]);

  return (
    <div className="w-full flex flex-col items-center">
      <div
        className="mt-10 px-1 ms:px-4
            w-[96%] md:w-[75%] lg:w-[65%] xl:w-[50%] flex flex-col gap-y-5 md:gap-y-6 lg:gap-y-8 
            rounded-md items-center justify-center"
      >
        <WordDetail audio={wordData?.eng_audio} show={true} />

        <div className="w-full h-[160px] md:h-[170px] xl:h-[240px] flex items-center justify-center md:gap-x-8 lg:gap-x-12">
          <WordDetail
            name={wordData?.french}
            audio={wordData?.french_audio}
            phenotic={wordData?.french_phenotic}
            show={french}
          />

          <div className="flex items-center w-[200px] md:w-[300px] xl:w-[350px] h-[160px] md:h-[150px] xl:h-[200px] ">
            <Swiper
              modules={[Pagination]}
              spaceBetween={50}
              slidesPerView={1}
              pagination={{
                clickable: true,
              }}
              onSwiper={(swiper) => console.log(swiper)}
              onSlideChange={() => console.log("slide change")}
              // className="m-0 p-0"
            >
              {showVideoFirst ? (
                <>
                  <SwiperSlide>
                    <video
                      ref={videoRef}
                      src={wordData?.video}
                      muted
                      controls
                      autoPlay
                      loop
                      className="m-0 p-0 outline-none h-[140px] md:h-[150px] xl:h-[200px] w-[200px] my-10 md:w-[300px] xl:w-[350px]"

                      // className="w-full h-full outline-none"
                    />
                  </SwiperSlide>
                  <SwiperSlide>
                    <img
                      src={wordData?.img}
                      alt={wordData?.img}
                      className="h-[140px] md:h-[150px] xl:h-[200px] w-[200px] my-10 md:w-[300px] xl:w-[350px] "
                    />
                  </SwiperSlide>
                </>
              ) : (
                <>
                  <SwiperSlide className="h-full w-full">
                    <img
                      src={wordData?.img}
                      alt={wordData?.img}
                      className="h-[100px] md:h-[150px] xl:h-[200px] w-[200px] my-10 md:w-[300px] xl:w-[350px] "
                      // className="h-full w-full"
                    />
                  </SwiperSlide>
                  <SwiperSlide className="h-full w-full">
                    <video
                      ref={videoRef}
                      src={wordData?.video}
                      muted
                      controls
                      autoPlay
                      loop
                      className="h-[100px] outline-none md:h-[150px] xl:h-[200px] w-[200px] my-10 md:w-[300px]
                       xl:w-[350px] "
                      // className="w-full h-full outline-none"
                    />
                  </SwiperSlide>
                </>
              )}
            </Swiper>
            <div className="swiper-pagination mt-20 absolute bottom-4 left-0 right-0"></div>
          </div>

          <WordDetail
            name={wordData?.chinese}
            audio={wordData?.chinese_audio}
            phenotic={wordData?.chinese_phenotic}
            show={chinese}
          />
        </div>

        <WordDetail
          name={wordData?.spanish}
          audio={wordData?.spanish_audio}
          phenotic={wordData?.spanish_phenotic}
          show={spanish}
        />
      </div>
    </div>
  );
}

export default WordFramePage;

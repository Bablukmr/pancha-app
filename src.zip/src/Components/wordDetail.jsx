export default function WordDetail({ name, audio, phenotic, show }) {
  console.log("show", show);
  return (
    <div className="w-[200px] flex flex-col items-center justify-center">
      {show && (
        <>
          <p>{name}</p>
          <div dangerouslySetInnerHTML={{ __html: phenotic }} />

          <button
            onClick={() => new Audio(audio).play()}
            className="cursor-pointer"
          >
            🔊
          </button>
        </>
      )}
    </div>
  );
}

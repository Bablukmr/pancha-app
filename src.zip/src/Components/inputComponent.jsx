
function InputComponent() {
  return (
    <div>InputComponet</div>
  )
}

export default InputComponent